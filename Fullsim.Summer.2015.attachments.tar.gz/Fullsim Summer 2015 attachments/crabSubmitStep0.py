from CRABClient.UserUtilities import config, getUsernameFromSiteDB
config = config()

config.General.requestName = 'custom_700_LSP100-43113_decayed_1000024_250__1000022_100'
config.General.workArea = 't2bw_fixup'
config.General.transferOutputs = True
config.General.transferLogs = True

config.JobType.pluginName = 'PrivateMC'
config.JobType.psetName = 'SUS_step0_cfg.py'

config.JobType.generator = 'lhe'

config.Data.primaryDataset = 't2bw'
config.Data.splitting = 'EventBased'
#config.Data.unitsPerJob = 1000
#NJOBS = 100
config.Data.unitsPerJob = 2500
NJOBS = 40
config.Data.totalUnits = config.Data.unitsPerJob * NJOBS
config.Data.outLFNDirBase = '/store/user/apatters/t2bw/'
#config.Data.outLFNDirBase = '/store/user/%s/' % (getUsernameFromSiteDB())
config.Data.publication = False
config.Data.ignoreLocality = True
#config.Site.whitelist = ["T2_US*"]
config.Site.whitelist = ['T2_US_MIT']
config.Site.blacklist = ['T2_US_Vanderbilt','T2_US_Purdue','T2_US_Caltech','T2_US_Nebraska']
config.Site.storageSite = 'T3_US_FNALLPC'
