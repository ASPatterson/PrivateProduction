#!/bin/bash
#source  /afs/cern.ch/cms/cmsset_default.sh
source /cvmfs/cms.cern.ch/cmsset_default.sh
source /cvmfs/cms.cern.ch/crab3/crab.sh

export SCRAM_ARCH=slc6_amd64_gcc491
if [ -r CMSSW_7_4_1_patch1/src ] ; then 
 echo release CMSSW_7_4_1_patch1 already exists
else
scram p CMSSW CMSSW_7_4_1_patch1
fi
cd CMSSW_7_4_1_patch1/src

scram b clean; scram b
eval `scram runtime -sh`

#export X509_USER_PROXY=$HOME/private/personal/voms_proxy.cert

cd ../../

# alex observation:
# for their pileup production they used MCRUN2_71_V1::All
# whereas they processed it using MCRUN2_74_V9 for DIGI-RECO. 

cmsDriver.py step1 \
--filein file:SUS-RunIIWinter15GS-T2tt_850_100-001.root \
--fileout file:SUS-RunIISpring15DR74-T2tt_850_100-001_step1.root \
--pileup_input das:/MinBias_TuneCUETP8M1_13TeV-pythia8/RunIIWinter15GS-MCRUN2_71_V1-v1/GEN-SIM \
--mc \
--eventcontent RAWSIM \
--pileup 2015_25ns_Startup_PoissonOOTPU \
--customise SLHCUpgradeSimulations/Configuration/postLS1Customs.customisePostLS1 \
--datatier GEN-SIM-RAW \
--conditions MCRUN2_74_V9 \
--step DIGI,L1,DIGI2RAW,HLT:@frozen25ns  \
--magField 38T_PostLS1 \
--python_filename SUS_step1_cfg.py \
-n -1 --no_exec

cmsDriver.py step2 \
--filein file:SUS-RunIISpring15DR74-T2tt_850_100-001_step1.root \
--fileout file:SUS-RunIISpring15DR74-T2tt_850_100-001_step2.root \
--mc \
--eventcontent AODSIM \
--customise SLHCUpgradeSimulations/Configuration/postLS1Customs.customisePostLS1 \
--datatier AODSIM \
--conditions MCRUN2_74_V9 \
--step RAW2DIGI,L1Reco,RECO,EI \
--magField 38T_PostLS1 \
--python_filename SUS_step2_cfg.py \
-n -1 --no_exec

cmsDriver.py step3 \
--filein file:SUS-RunIISpring15DR74-T2tt_850_100-001_step2.root \
--fileout file:SUS-RunIISpring15DR74-T2tt_850_100-001_step3.root \
--mc \
--eventcontent MINIAODSIM \
--runUnscheduled \
--customise SLHCUpgradeSimulations/Configuration/postLS1Customs.customisePostLS1 \
--datatier MINIAODSIM \
--conditions MCRUN2_74_V9 \
--step PAT \
--python_filename SUS_step3_cfg.py \
-n -1 --no_exec
