from CRABClient.UserUtilities import config, getUsernameFromSiteDB
config = config()

config.General.requestName = 'custom_700_LSP100-43113_decayed_1000024_250__1000022_100_step3'
config.General.workArea = 't2bw_step3'
config.General.transferOutputs = True
config.General.transferLogs = True

config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'SUS_step3_cfg.py'

config.Data.primaryDataset = 't2bw_step3'

config.Data.userInputFiles = open('list.txt').readlines()

# uncomment to receive printout of files it finds in list.txt
#print(config.Data.userInputFiles)

# for sanity check, can do instead ['A','B','C'...]
#config.Data.userInputFiles=['root://cms-xrd-global.cern.ch//store/user/apatters/mcproduction/step0/T2tt/T2tt_850_LSP100x57800_decayed_1000022_100_1.root']

config.Data.splitting = 'FileBased'
# 'units' means files for file-based splitting
#           and events for event-based splitting
config.Data.unitsPerJob = 1
# totalUnits not necessary
#config.Data.totalUnits = 40

config.Data.outLFNDirBase = '/store/user/apatters/t2bw/'
#config.Data.outLFNDirBase = '/store/user/%s/' % (getUsernameFromSiteDB())
config.Data.publication = False
#config.Data.ignoreLocality = True
config.Site.whitelist =	['T2_US_MIT']
config.Site.blacklist = ['T2_US_Vanderbilt','T2_US_Purdue','T2_US_Wisconsin','T2_US_Caltech','T2_US_UCSD']
config.Site.storageSite = 'T3_US_FNALLPC'
