#!/bin/bash
source /cvmfs/cms.cern.ch/cmsset_default.sh
source /cvmfs/cms.cern.ch/crab3/crab.sh

export SCRAM_ARCH=slc6_amd64_gcc481
if [ -r CMSSW_7_1_15_patch1/src ] ; then 
	echo release CMSSW_7_1_15_patch1 already exists
else
	scram p CMSSW CMSSW_7_1_15_patch1
fi

cd CMSSW_7_1_15_patch1/src
cmsenv
git cms-addpkg Configuration/Generator
cp ../../genfragment.py Configuration/Generator/python/
cd Configuration/Generator/python/
scram b clean; scram b
cd ../../..
scram b
cd ../..

cmsDriver.py Configuration/Generator/python/genfragment.py \
--filein file:/eos/uscms/store/user/apatters/mcproduction/T2tt_850_LSP100x38898_decayed_1000022_100.lhe \
--fileout file:/eos/uscms/store/user/apatters/mcproduction/SUS-RunIIWinter15GS-T2tt_850_100-001_step0.root \
--mc \
--eventcontent RAWSIM \
--customise SLHCUpgradeSimulations/Configuration/postLS1Customs.customisePostLS1 \
--datatier GEN-SIM \
--conditions MCRUN2_71_V1::All \
--beamspot NominalCollision2015 \
--step GEN,SIM \
--magField 38T_PostLS1 \
--python_filename SUS_step0_cfg.py \
-n -1 --no_exec
