# mass_dict.py and tutorial.cfg are for T2bW. See instructions.txt for T2tt, which is done mostly automatically.
# Configuration dictionary for three different configurations
conf1 = {"1000024" : 250,
         "1000022" : 100}
conf2 = {"1000024" : 400,
         "1000022" : 100}
conf3 = {"1000024" : 550,
         "1000022" : 100}
conf4 = {"1000024" : 187.5,
         "1000022" : 50}
conf5 = {"1000024" : 325,
         "1000022" : 50}
conf6 = {"1000024" : 462.5,
         "1000022" : 50}

# Required mass dictionary.
mass_dict = {"700" : [conf1, conf2, conf3],
             "600" : [conf4, conf5, conf6]}

